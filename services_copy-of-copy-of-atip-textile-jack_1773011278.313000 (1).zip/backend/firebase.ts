import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';

// ------------------------------------------------------------------
// ⚠️ IMPORTANT: REPLACE THE VALUES BELOW WITH YOUR FIREBASE CONFIG
// You can find these in the Firebase Console > Project Settings > General
// ------------------------------------------------------------------
const firebaseConfig = {
  apiKey: "YOUR_API_KEY",
  authDomain: "YOUR_PROJECT_ID.firebaseapp.com",
  projectId: "YOUR_PROJECT_ID",
  storageBucket: "YOUR_PROJECT_ID.appspot.com",
  messagingSenderId: "YOUR_MESSAGING_SENDER_ID",
  appId: "YOUR_APP_ID"
};

const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);